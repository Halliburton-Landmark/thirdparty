The contents of this project have moved to the two projects:

org.eclipse.ecf/examples/bundles

org.eclipse.ecf.examples.eventadmin
org.eclipse.ecf.examples.eventadmin.app

