package test3;

@SuppressWarnings("unused")
class Visible2 {
    public int pub;
    protected int pro;
    private int pri;
    int pack;
}

@SuppressWarnings("unused")
public class Visible {
    public int pub;
    protected int pro;
    private int pri;
    int pack;
}
