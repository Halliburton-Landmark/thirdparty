package test2;

public class ConstField {
    public static final boolean b = true;
    public static final int i = 3;
    public static final long j = 7L;
    public static final float f = 8.0F;
    public static final double d = 9.0;
    public static final String s = "const";
    public static final Object obj = null;
    public static final Integer integer = Integer.valueOf(4);
    public static int k = 2;
}
