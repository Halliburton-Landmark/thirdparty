This directory contains files used by the unit tests.

empty.jar:
An empty, but valid, jar file.

simple.jar:
Contains a single Java class

```
package com.test;

public class Test {
	public Test() {
	}
}
```
